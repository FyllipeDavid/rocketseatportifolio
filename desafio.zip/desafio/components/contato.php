<br><br>
<br><br>
<br><br>
<section class="
    text-white mx-auto  max-w-screen-lg 
    px-3 
    text-white align-items-center " style="height: 90vh;">
    <div class="py-4 my-4">
        <h2 style="font-size:3rem; " class="font-semibold  text-center  ">Contato</h2>
        <hr class="w-50 mx-auto" style="color:#0d6efd;margin: 3% 0;max-width:10%;border:5px solid" />
        <h4 class="text-center my-4 ">Vamos conversar sobre seu próximo projeto</h4>
    </div>

    <div class="container">
        <div class="row  row-cols-2 row-cols-lg-2">
            <h3>Vamos conversar</h3>
            <p>
                Estou sempre aberto a discutir novos projetos, ideias criativas ou oportunidades para fazer parte de suas visões.
            </p>

            <div class="">
                <div class="">
                    <i class="fa-regular fa-message"></i>
                </div>
                <div ">
                    <h5>
                        Email
                    </h5>
                    <p>fyllipedavid@hotmail.com</p>
                </div>
            </div>
            <div class="">
                <div class="">
                    <i class="fa-solid fa-location-crosshairs"></i>
                </div>
            <div ">
                <h5>
                    Localização
                </h5>
                <p>Brasil</p>
            </div>
            </div>
        </div>

        <hr>
        <div class="row row-cols-2 row-cols-lg-2">

          <form>
                <div class=" mb-3">
                        <label for="exampleInputEmail1" class="form-label">Email address</label>
                        <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                        <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">Password</label>
                        <input type="password" class="form-control" id="exampleInputPassword1">
                    </div>
                    <div class="mb-3 form-check">
                        <input type="checkbox" class="form-check-input" id="exampleCheck1">
                        <label class="form-check-label" for="exampleCheck1">Check me out</label>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                    </form>

                </div>
            </div>

</section>