<?php
$projects = [
    [
        "src"         => "./img/portifolio.png",
        "alt"         => "Imagem do portifolio",
        "title"       => "Portifólio Bootstrap",
        "description" => "Uma apresentação web de minhas habilidades funcionais",
        "href"        => "https://google.com",
        "text"        => "Ver Portifolio",
        "icon"        => "fa-brands fa-github",
        "href-icon"   => "https://github.com/perfil",
        "slacks"      => ["PHP", "HTML", "CSS", "Javascript"],
        "finalizado"  => true
    ],
    [
        "src"         => "./img/portifolio.png",
        "alt"         => "Imagem do portifolio",
        "title"       => "Portifólio Tailwind",
        "description" => "Uma apresentação web de minhas habilidades funcionais",
        "href"        => "https://google.com",
        "text"        => "Ver Portifolio",
        "icon"        => "fa-brands fa-github",
        "href-icon"   => "https://github.com/perfil",
        "slacks"      => ["PHP", "HTML", "CSS", "Javascript"],
        "finalizado"  => true
    ],
    [
        "src"         => "./img/portifolio.png",
        "alt"         => "Imagem do portifolio",
        "title"       => "Sistema de Gerenciamento",
        "description" => "Plataforma completa para gestão de processos empresariais com dashboard interativo e relatórios em tempo real.",
        "href"        => "https://google.com",
        "text"        => "Ver Portifolio",
        "icon"        => "fa-brands fa-github",
        "href-icon"   => "https://github.com/perfil",
        "slacks"      => ["PHP", "HTML", "CSS", "Javascript"],
        "finalizado"  => false
    ],
    [
        "src"         => "./img/portifolio.png",
        "alt"         => "Imagem do portifolio",
        "title"       => "Plataforma e-commerce",
        "description" => "Loja virtual moderna com carrinho de compras, sistema de pagamento integrado e painel administrativo completo.",
        "href"        => "https://google.com",
        "text"        => "Ver Portifolio",
        "icon"        => "fa-brands fa-github",
        "href-icon"   => "https://github.com/perfil",
        "slacks"      => ["PHP", "HTML", "CSS", "Javascript"],
        "finalizado"  => false
    ]
];

?>


<section class="
    text-white mx-auto  max-w-screen-lg 
    px-3 
    text-white align-items-center " style="height: 90vh;">
    <div class="py-4">
        <h2 style="font-size:3rem; " class="font-semibold  text-center  ">Projetos</h2>
        <hr class="w-50 mx-auto" style="color:#0d6efd;margin: 3% 0;max-width:10%;border:5px solid" />
        <h4 class="text-center my-4 ">Confira alguns dos meus trabalhos concluídos e em desenvolvimento</h4>
    </div>

    <div class="">

        <div class="d-flex  rounded-3 p-4 mx-auto " style="width: 100%; color:white ">
            <!-- <img src="" class="card-img-top " alt="..." > -->
            <?php foreach ($projects as  $project): ?>
                <div class="m-4 border rounded-3 w-25 px-1 " >
                    <img  src="<?= $project['src'] ?>" alt="<?= $project['alt'] ?>" class="w-100 shadow-md">
                    <h5 class="card-title fs-4 text"><?= $project['title'] ?></h5>
                    <p class="card-text ">Uma apresentação web de minhas habilidades funcionais</p>
                    <button type="button" class="btn btn-<?= ($project['finalizado'])? 'success' : 'warning' ?>">
                            <?= ($project['finalizado'])? 'Finalizado' : 'Em Progresso' ?>
                        </button>
                        
                        <br>
                        <br>
                    <?php foreach ($project['slacks'] as $skills => $skill): ?>
                        <button type="button" class="btn btn-light">
                            <?= $skill ?></span>
                        </button>
                    <?php endforeach; ?>
                    
                    <br>
                    <button type="button" class="btn btn-primary my-4 w-75">
                        <?= $project['text'] ?>
                    </button>
                    <a href="<?= $project['href-icon'] ?>" class="btn btn-primary "><i class="<?= $project['icon'] ?>"></i></a>
                </div>
            <?php endforeach; ?>
        </div>



    </div>

</section>