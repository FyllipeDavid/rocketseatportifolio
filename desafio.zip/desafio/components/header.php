<?php
$items = [
    ['href' => '#', 'texto' => 'Home'],
    ['href' => '#sobre', 'texto' => 'Sobre'],
    ['href' => '#projetos', 'texto' => 'Projetos'],
    ['href' => '#tecnologias', 'texto' => 'Tecologias'],
    ['href' => '#contato', 'texto' => 'Contato']
];

?>




<header class="mx-auto max-w-screen-lg px-3 py-6 flex items-middle justify-between bg-neutral-950 ">

    <!-- logo e menu-->

    <nav class="navbar navbar-expand-lg navbar-light bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand text-white" href="#"> <h2>Portifólio</h2></a>
            <div class="">
                <ul class="list-group list-group-horizontal">
                    <?php foreach ($items as $item): ?>
                        <li class=" list-unstyled">
                            <a style="text-decoration:none;" href="<?= $item['href'] ?>" class="mx-4 link-light">
                                <?= $item['texto'] ?>
                            </a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </nav>


</header>