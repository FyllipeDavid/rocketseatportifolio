<hr><hr><hr><hr><hr>
<footer style="color:#fff; background-color:#000" class="position-static p-4">
    Desenvolvido com PHP, HTML e CSS.   Todos os direitos reservados. Portifólio - Fyllipe David
</footer>