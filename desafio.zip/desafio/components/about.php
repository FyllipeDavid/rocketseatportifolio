<section class="
    text-white mx-auto  max-w-screen-lg 
    px-3 
    text-white align-items-center " style="height: 90vh;">
    <div class="py-4">
        <h2 style="font-size:3rem; " class="font-semibold  text-center  ">Sobre Mim</h2>
        <hr class="w-50 mx-auto" style="color:#0d6efd;margin: 3% 0;max-width:10%;border:5px solid" />
        <h3 class="text-center my-4">Desenvolvedor apaixonado por criar experiências digitais incríveis</h3>
    </div>

    <div class="d-flex justify-content-center center">
        <div class="" style="width:38%;margin:0 5%">
            <article class="">
                <p>
                    Sou um desenvolvedor PHP com experiência sólida em desenvolvimento web full stack. Minha jornada na programação começou com a curiosidade de entender como as coisas funcionam na web, e hoje transformo essa paixão em soluções reais.
                    Com domínio em PHP, HTML, CSS e JavaScript, já concluí 2 projetos completos e continuo desenvolvendo novas aplicações. Busco sempre as melhores práticas de código e experiência do usuário em cada projeto.
                </p>
            </article>
            <ul class="d-flex ">
                <li class="list-unstyled">
                    <div class=" px-2 " style="margin-left:-2rem">
                        <span class="text-primary" style="font-size: 25pt;">
                            2+
                        </span></br>
                        <span style="font-weight: bold;">Projetos Concluídos</span>
                    </div>

                </li>
                <li class="list-unstyled">
                    <div class="px-2 ">
                        <span class="text-primary" style="font-size: 25pt;">
                            4
                        </span>
                        </br>
                        <span style="font-weight: bold"> Tecnologias</span>
                    </div>

                </li>
                <li class=" list-unstyled">
                    <div class="px-2 ">
                        <span class="text-primary" style="font-size: 25pt;">
                            100%
                        </span> </br>
                        <span style="font-weight: bold">Dedicação </span>
                    </div>

                </li>
            </ul>
        </div>
        <div class=" p-3 row justify-content-middle bg-primary bg-gradient " style="width:25%;border-radius:1rem">
            <div class="d-flex justify-content-start ">
                <div class="p-4">
                    <i class="fa-solid fa-code" style="align-self:center"></i>
                </div>
                <div>
                    <h3>Clean Code</h3>
                    <span>Código limpo e manutenível</span>
                </div>
            </div>
            <div class="d-flex justify-content-start">
                <div class="p-4">
                    <i class="fa-regular fa-lightbulb" style="align-self:center"></i>
                </div>
                <div>
                    <h3>Soluções Criativas</h3>
                    <span>Pensamento inovador</span>
                </div>
            </div>
            <div class="d-flex justify-content-start">
                <div class="p-4">
                    <i class="fa-solid fa-rocket" style="align-self:center"></i>
                </div>

                <div>
                    <h3>Performance</h3>
                    <span>Em constante otimização</span>
                </div>
            </div>
        </div>
    </div>

</section>