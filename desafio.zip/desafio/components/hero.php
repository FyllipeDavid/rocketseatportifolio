<?php
$medias = [
    [
        "href" => "https://github.com",
        "src" => "./img/github.png",
        "alt" => "ìcone botão github"
    ],
    [
        "href" => "https://facebook.com",
        "src" => "./img/facebook.png",
        "alt" => "ìcone botão facebook"
    ],
    [
        "href" => "https://instagram.com",
        "src" => "./img/instagram.jpg",
        "alt" => "ìcone botão instagram"
    ],
    [
        "href" => "https://linkedin.com",
        "src" => "./img/linkedin.jpg",
        "alt" => "ìcone botão linkedin"
    ]
];
?>

<div class="container-md px-5 mx-5" style="color:#fff; height:90vh">
    <section class="text-center mt-5">
        <p class="font-bold text-7xl" style="font-weight:bold;font-size:5rem">
            Desenvolvedor PHP
        </p>
    </section>
    <section class="text-center ">
        <p class="" style="font-size:3rem; font-weight:light;">
            Full Stack Developer
        </p>
    </section>
    <section class="   text-center px-4 py-3 mt-5" style="width: 80%;justify-self:center">
        Especializado em desenvolvimento web com PHP, criando soluções robustas e escaláveis.
        Transformo ideias em aplicações funcionais e elegantes.
    </section>
    <section>
        <ul class="d-flex justify-content-center mt-5 ">
            <a href="#projetos" class="btn btn-primary rounded-4 p-1 rounded-md bg-blue-500 transition delay-150 duration-300 ease-in-out hover:-translate-y-1 hover:scale-110 hover:bg-indigo-500" style="font-size:16pt">
                Ver Projetos
            </a>
            <a href="#contato" class="btn btn-dark p-2 transition delay-150 duration-300 ease-in-out hover:-translate-y-1 hover:scale-110 hover:bg-indigo-500 rounded-md hover:bg-white hover:text-gray-900" style="font-size:16pt">
                Entrar em contato
            </a>
        </ul>
    </section>
    <section>
        <ul class="d-flex text-center justify-content-center  py-3">
            <?php foreach ($medias as $media): ?>
                <li class="list-unstyled">
                    <a href="<?= $media['href'] ?>">
                        <img style="width:3rem" src="<?= $media['src'] ?>" alt="<?= $media['alt'] ?>" class="mx-2">
                    </a>
                </li>
            <?php endforeach ?>
        </ul>
    </section>
</div>